#payment gateway setup

#this will set a payment for single and subscription
